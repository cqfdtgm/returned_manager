tes for README.rst
